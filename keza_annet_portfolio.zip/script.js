// Interactive Script for Portfolio

document.addEventListener('DOMContentLoaded', () => {
    console.log("Portfolio loaded successfully for KEZA Annet!");

    // Simple mobile menu toggle functionality
    const menuToggle = document.getElementById('mobile-menu');
    const navUl = document.querySelector('header nav ul');

    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            if (navUl.style.display === 'flex') {
                navUl.style.display = 'none';
            } else {
                navUl.style.display = 'flex';
                navUl.style.flexDirection = 'column';
                navUl.style.position = 'absolute';
                navUl.style.top = '70px';
                navUl.style.left = '0';
                navUl.style.width = '100%';
                navUl.style.background = '#ffffff';
                navUl.style.padding = '20px';
                navUl.style.boxShadow = '0 5px 5px rgba(0,0,0,0.1)';
            }
        });
    }

    // Smooth scrolling effect for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});
